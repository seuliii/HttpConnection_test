package com.example.yogatintegration;

import android.content.ContentValues;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.hardware.Camera;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.yanzhenjie.permission.Action;
import com.yanzhenjie.permission.AndPermission;

import org.w3c.dom.Text;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class MainActivity extends AppCompatActivity {

    //MainActivity
    static Context context;
    TimerTask tt;

    //send image to Django
    static String imageString;
    private String responseData;
    private byte[] pictureByteArr;
    Bitmap imageBitmap;
    //layout
    private Button captureBtn;
    private Button sendToServerBtn;
    private Button ttsBtn;
    private Button stopBtn;
    private ImageView imageView;

    //camera preview
    private Camera mCamera;
    private int mCameraFacing;
    private FrameLayout preview;
    private CameraPreview mCameraView;

    //object
    private OKHttpConnection okHttpConnection;
    private TextToSpeech_yogat tts;
    private SetImageView setImageView;

    //timer
    private static final int MILLISINFUTURE = 3 * 1000;
    private static final int COUNT_DOWN_INTERVAL = 1000;
    CountDownTimer countDownTimer;
    private int count = 3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //초기화
        mCamera = getCameraInstance();
        context = getApplicationContext();
        preview = findViewById(R.id.preview);
        okHttpConnection  = new OKHttpConnection();
        tts = new TextToSpeech_yogat();
        imageView = findViewById(R.id.imageView);
        setImageView = new SetImageView();



        //카메라 프리뷰
        //mCameraFacing = 전면 or 후면을 결정
        mCameraFacing = (mCameraFacing == Camera.CameraInfo.CAMERA_FACING_BACK) ?
                Camera.CameraInfo.CAMERA_FACING_FRONT
                : Camera.CameraInfo.CAMERA_FACING_BACK;

        mCameraView = new CameraPreview(this, mCamera, mCameraFacing,imageView);
        //imageView.setImageResource(R.drawable.yoga_pose);

        preview.addView(mCameraView);
       // setImageView.execute();


        //촬영 버튼
        captureBtn = findViewById(R.id.captureBtn);
        captureBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    timerInTakingPictures();


            }
        });

        //정지 버튼
        stopBtn = findViewById(R.id.stopBtn);
        stopBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //타이머 해제
                tt.cancel();
            }
        });

        //서버 전송
        sendToServerBtn = findViewById(R.id.sendToServerBtn);
        sendToServerBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public
            void onClick(View v) {
                responseData = OKHttpConnection.responseData;
                Log.d("timecheck",responseData+ "dsfdsfsfd");
            }
        });

        //tts
        ttsBtn = findViewById(R.id.ttsBtn);
        ttsBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tts.sayText(responseData);


            }
        });

        //권한 허가 (onCreate메소드 안에서 호출해야 함)
        AndPermission.with(this)
                .runtime()
                .permission(
                        com.yanzhenjie.permission.runtime.Permission.CAMERA,
                        com.yanzhenjie.permission.runtime.Permission.RECORD_AUDIO,
                        com.yanzhenjie.permission.runtime.Permission.READ_EXTERNAL_STORAGE,
                        com.yanzhenjie.permission.runtime.Permission.WRITE_EXTERNAL_STORAGE)
                .onGranted(new Action<List<String>>() {
                    @Override
                    public void onAction(List<String> permissions) {
                        Toast.makeText(MainActivity.context,"허용된 권한 갯수: " + permissions.size(),Toast.LENGTH_LONG).show();
                    }
                })
                .onDenied(new Action<List<String>>() {
                    @Override
                    public void onAction(List<String> permissions) {
                        Toast.makeText(MainActivity.context,"거부된 권한 갯수: " + permissions.size(),Toast.LENGTH_LONG).show();
                    }
                })
                .start();
    }   //onCreate


    //Django서버에 이미지를 전송
    public void sendToServer() {
        try {

            //http통신에선 데이터를 주고 받을 때 String형식을 통해 주고받을 수 있음
            //Base64를 통해서 byteArray를 String으로 변환해서 전송
            imageBitmap =  mCameraView.getBitmap();
            Log.d("check","imageBitmap in Main is" + imageBitmap);
            pictureByteArr = bitmapToByteArray(imageBitmap);
            imageString = Base64Util.encode(pictureByteArr);

        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        okHttpConnection.sendToServer(imageString);

    }

    public Camera getCameraInstance() {
        Camera c = null;
        try {
            // attempt to get a Camera instance
            c = Camera.open();
        } catch (Exception e) {
            e.printStackTrace();
        }
        // returns null if camera is unavailable
        return c;
    }
    
    //timer가 끝난 후 사진 촬영
    public void timerInTakingPictures(){

        //timer가 실행될 때 해야할 일
        tt = new TimerTask() {
            @Override
            public void run() {
                mCameraView.capture();
                pictureByteArr = CameraPreview.imagebytes;
                sendToServer();

            }
        };
        
        //timer 설정 (해야할 일 , 몇 초후에 시작할지, 타이머 주기)
        Timer timer = new Timer();
        timer.schedule(tt,3000,3000);

        }


    public byte[] bitmapToByteArray (Bitmap $bitmap){

        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        $bitmap.compress(Bitmap.CompressFormat.JPEG, 100, stream);
        byte[] byteArray = stream.toByteArray();
        return byteArray;
    }
        public class SetImageView extends AsyncTask<Void,Void,Void>{


            @Override
            protected Void doInBackground(Void... voids) {
                preview.addView(imageView);
                return null;
            }
        }



}
